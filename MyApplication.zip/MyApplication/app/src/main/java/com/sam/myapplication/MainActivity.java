package com.sam.myapplication;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity implements View.OnClickListener{

 Controldb db  = new Controldb(this);
 SQLiteDatabase database;
 EditText name, rollno,age;
 Button save,show;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        name = (EditText)findViewById(R.id.ed_name);
        rollno = (EditText)findViewById(R.id.ed_rollno);
        age = (EditText)findViewById(R.id.ed_age);

        save = (Button)findViewById(R.id.btn_save);
        show = (Button)findViewById(R.id.btn_show);

    }
        @Override
    public void onClick(View view)
        {
            if(view.getId()==R.id.btn_save)
            {
                database = db.getWritableDatabase();
                database = execSQL("INSERT INTO Studentdetails (Studname,StudRollno,Age) VALUES(" + name.getText() + " , " + rollno.getText() + " , " + age.getText() + ")");

                Toast.makeText(this, "Data insertion Successful", Toast.LENGTH_LONG).show();

            }
            else if (view.getId()==R.id.btn_show){

                Intent intent = new Intent(this , MainActivity.class);
                startActivity(intent);
            }
        }

        }




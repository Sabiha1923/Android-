package com.sam.myapplication;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.database.Cursor;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ListView;
import java.util.ArrayList;
public class ActivityListview extends AppCompatActivity {

    Controldb controldb = new Controldb(this);
    SQLiteDatabase db;
    private ArrayList<String> name = new ArrayList<String>();
    private ArrayList<String> rollno = new ArrayList<String>();
    private ArrayList<String> age = new ArrayList<String>();
    ListView listView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setContentView(R.layout.activity_listview);
        listView = (ListView) findViewById(R.id.lstview);

            }
    protected  void displayData()
            {
                db = controldb.getReadableDatabase();
                Cursor cursor = db.rawQuery("SELECT * FROM Studentdetails ", null);
                name.clear();
                rollno.clear();
                age.clear();

    }

}
